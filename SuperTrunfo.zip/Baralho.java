import java.util.ArrayList;
import java.util.Collections;

public class Baralho {
	ArrayList<Carta> Cartas;

	public Baralho() {
		this.Cartas = new ArrayList<Carta>();
		this.Cartas.add(new Carta("Finn", 1, 'A', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Jake", 2, 'A', 15, 10, 2, 10, 7, false));
		this.Cartas.add(new Carta("Marceline", 3, 'A', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Lich", 4, 'A', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Princesa Jujuba", 5, 'A', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Rei Gelado", 6, 'A', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Princesa Fogo", 7, 'A', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Princesa Caroco", 8, 'A', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Lady Iris", 1, 'B', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Golb", 2, 'B', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Babolha", 3, 'B', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Betty", 4, 'B', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Bob", 5, 'B', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Booko", 6, 'B', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Canelinha", 7, 'B', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Caracol", 8, 'B', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Darren", 1, 'C', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Ed", 2, 'C', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("DoutorRosquinha", 3, 'C', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("CoronelMilhoDoce", 4, 'C', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("CondeDeLimao", 5, 'C', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("ChicoBanana", 6, 'C', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Cerejinha", 7, 'C', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Minerva", 8, 'C', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Prismo", 1, 'D', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Ricardio", 2, 'D', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Lomo", 3, 'D', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("SrTromba", 4, 'D', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("ReiDaFesta", 5, 'D', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Shet", 6, 'D', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("SrCremoso", 7, 'D', 45, 11, 35, 47, 7, false));
		this.Cartas.add(new Carta("Fionna", 8, 'D', 45, 11, 35, 47, 7, false));

	}

	public void Embaralhar() {
		Collections.shuffle(this.Cartas);

	}

}
