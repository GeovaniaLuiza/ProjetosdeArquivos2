import java.util.ArrayList;
import java.util.Random;

public class Jogador {
	String nomeJogador;
	Boolean computadorJogador;
	ArrayList<Carta> Cartas;
	Carta CartaRodada;
	Boolean VencedorDaRodada;

	public Jogador(String nomeJogador, boolean computadorJogador) {
		this.nomeJogador = nomeJogador;
		this.computadorJogador = computadorJogador;
		this.VencedorDaRodada = false;
		this.Cartas = new ArrayList<Carta>();
	}

	public Carta PegarCarta() {
		this.CartaRodada = Cartas.get(0);
		if (!this.computadorJogador)
			this.CartaRodada.apresentaCarta();
		this.Cartas.remove(0);
		return this.CartaRodada;
	}

	public int SelecionarCaracteristica() {
		if (this.computadorJogador) {
			Random gerador = new Random();
			return gerador.nextInt(5) + 1;
		} else {
			SolicitaCaract user = new SolicitaCaract();
			return user.SolicitaCaracteristica();
		}

	}

}