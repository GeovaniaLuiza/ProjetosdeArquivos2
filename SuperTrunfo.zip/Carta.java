import java.util.List;

public class Carta { 
	String Nome;
	int numCarta;
	char letraCarta;
	int poder;
	int inteligencia;
	int for�a;
	int espiritoAvent;
	int amizade;
	boolean SuperTrunfo;

	public Carta(String Nome, int numCarta, char letraCarta, int poder, int inteligencia, int forca, int espiritoAvent,
			int amizade, boolean SuperTrunfo) {
		this.Nome = Nome;
		this.letraCarta = letraCarta;
		this.numCarta = numCarta;
		this.poder = poder;
		this.inteligencia = inteligencia;
		this.for�a = forca;
		this.espiritoAvent = espiritoAvent;
		this.amizade = amizade;
		this.SuperTrunfo = SuperTrunfo;
	}

	public void apresentaCarta() {
		System.out.println("Nome: " + this.Nome);
		System.out.println("Sigla: " + this.numCarta + this.letraCarta);
		if (this.SuperTrunfo)
			System.out.println("Carta SUPER TRUNFO.");
		else {
			System.out.println("1- Poder: " + this.poder);
			System.out.println("2- Inteligencia: " + this.inteligencia);
			System.out.println("3- Forca: " + this.for�a);
			System.out.println("4- Espirito Aventureiro: " + this.espiritoAvent);
			System.out.println("5- Amizade " + this.amizade);
		}
	}

	
	public Carta DefineCartaVencedora(List<Carta> Cartas, int CaracteristicaEscolhida){
		
		Carta cartaVencedora = Cartas.get(0);
		int cartasA = 0;
		boolean empate=false;

		for (int i = 1; i<Cartas.size() ; i++){
			if (Cartas.get(i).SuperTrunfo){  //Verificacao se eh a carta supertrunfo
				cartaVencedora = Cartas.get(i);
				for (int j = 0; j<Cartas.size() ; j++){
					if (Cartas.get(j).letraCarta == 'A'){
						cartaVencedora = Cartas.get(j);
						cartasA++;
					}
				}
				if (cartasA == 0 || cartasA == 1)
					return cartaVencedora;
				else 
					return null;
			}
		}
		
		for (int i = 1; i<Cartas.size() ; i++)
		{
			switch (CaracteristicaEscolhida){
			case 1:
				if(cartaVencedora.amizade < Cartas.get(i).amizade){
					cartaVencedora = Cartas.get(i);
					empate=false;
				}
				else 
					if (cartaVencedora.amizade == Cartas.get(i).amizade)
						empate = true;
				break;
			case 2:
				if(cartaVencedora.poder < Cartas.get(i).poder){
					cartaVencedora = Cartas.get(i);
					empate=false;
				}
				else 
					if (cartaVencedora.poder == Cartas.get(i).poder)
						empate = true;
				break;
			case 3:
				if(cartaVencedora.for�a < Cartas.get(i).for�a){
					cartaVencedora = Cartas.get(i);
					empate=false;
				}
				else 
					if (cartaVencedora.for�a
							== Cartas.get(i).for�a)
						empate = true;
				break;
			case 4:
				if(cartaVencedora.espiritoAvent < Cartas.get(i).espiritoAvent){
					cartaVencedora = Cartas.get(i);
					empate=false;
				}
				else 
					if (cartaVencedora.espiritoAvent == Cartas.get(i).espiritoAvent)
						empate = true;
				break;
			default:
				if(cartaVencedora.inteligencia < Cartas.get(i).inteligencia){
					cartaVencedora = Cartas.get(i);
					empate=false;
				}
				else 
					if (cartaVencedora.inteligencia == Cartas.get(i).inteligencia)
						empate = true;
				break;
			}
			
		}
		if (!empate)
			return cartaVencedora;
		else 
			return null;
	}
}

