import java.util.ArrayList;

public class Jogo {
	ArrayList<Jogador> Jogadores;
	ArrayList<Carta> Cartas;
	Baralho Baralho;
	int CaracteristicaEscolhida;

	public Jogo() {
		this.Jogadores = new ArrayList<Jogador>();
		this.Cartas = new ArrayList<Carta>();
	}

	public void criarJogo() {
		this.Jogadores.add(new Jogador("Jogador1", false));
		this.Jogadores.add(new Jogador("Jogador2", true));
		this.Baralho = new Baralho();
		this.Baralho.Embaralhar();
		this.DistribuirCartas();
	}

	public void DistribuirCartas() {
		
		int cartasPorJogador = this.Baralho.Cartas.size() / this.Jogadores.size();
		
		System.out.println("Cada jogador possui " + cartasPorJogador + " cartas.");
		for (int i = 0; i < cartasPorJogador; i++) {
			for (int j = 0; j < this.Jogadores.size(); j++) {
				this.Jogadores.get(j).Cartas.add(this.Baralho.Cartas.get(0));
				this.Baralho.Cartas.remove(0);
			}
		}
		if (this.Baralho.Cartas.size() > 0) {
			System.out.println("Sobraram " + this.Baralho.Cartas.size() + "na primeira rodada.");
			this.Cartas = this.Baralho.Cartas;
			this.Baralho.Cartas.clear();
		}
	}
	
	public void CriarJogo(){
		this.Jogadores.add(new Jogador("Player1", false));
		this.Jogadores.add(new Jogador("Player2", true));
		this.Baralho = new Baralho();
		this.Baralho.Embaralhar();
		this.DistribuirCartas();
	}
	
	public void VencedorEscolheAtributo(){
            
            for (int i= 0; i < this.Jogadores.size(); i++){
                if (this.Jogadores.get(i).VencedorDaRodada)
                   this.CaracteristicaEscolhida = this.Jogadores.get(i).SelecionarCaracteristica();
                   System.out.println("Atreibuto escolhido: " + this.CaracteristicaEscolhida);
            } 
        }
        
	//INICIAR UMA RODADA.
	public void IniciarJogo(){
        
		int count=0;
		
        while (!this.verificarFimdoJogo()){
        	this.Cartas.add(this.Jogadores.get(0).PegarCarta());
        	this.Cartas.add(this.Jogadores.get(1).PegarCarta());
                  if (count==0)
                      this.CaracteristicaEscolhida = this.Jogadores.get(0).SelecionarCaracteristica();
                  else 
                      this.VencedorEscolheAtributo();                                    
		  this.DefinirVencedorDaRodada();
		  this.VerficarJogadoresSemCartas();
		  this.verificarFimdoJogo();
		}
		  
	}

	public void DefinirVencedorDaRodada(){
		Carta cartaVencedora =this.Cartas.get(0).DefineCartaVencedora(this.Cartas, this.CaracteristicaEscolhida);
		if (cartaVencedora == null){
			System.out.println("Nao existe vencedor da rodada.");
		} else {
			for(int i = 0; i < this.Jogadores.size(); i++){
				if (this.Jogadores.get(i).CartaRodada == cartaVencedora){
					System.out.println("Jogador vencedor da rodada:" + this.Jogadores.get(i).nomeJogador);
					for(Carta elemento: this.Cartas){
						this.Jogadores.get(i).Cartas.add(elemento);
					}
					this.Cartas.clear();
				}
			}
		}
	}

	public void VerficarJogadoresSemCartas(){
		for (int i = 0; i <this.Jogadores.size(); i++){
			
			if (this.Jogadores.get(i).Cartas.size()==0)
				this.Jogadores.remove(i);
				
		}
	}
	
	public boolean verificarFimdoJogo(){
		if (this.Jogadores.size() == 1){
			System.out.println("Jogador vencedor da partida:" + this.Jogadores.get(0).nomeJogador);
			return true;
		}
		else 
			return false;
		
	}
}


