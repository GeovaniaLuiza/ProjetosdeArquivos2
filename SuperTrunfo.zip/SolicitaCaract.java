import java.util.Scanner;

public class SolicitaCaract {
	Scanner scanner = new Scanner(System.in);

	public int SolicitaCaracteristica() {
		System.out.println("Informe o numero da caracteristica selecionada: ");
		System.out.println("1 - Poder");
		System.out.println("2 - Inteligencia");
		System.out.println("3 - Forca");
		System.out.println("4 - Espirito Aventureiro");
		System.out.println("5 - Amizade");
		System.out.println("");
		return this.scanner.nextInt();
	}

}
